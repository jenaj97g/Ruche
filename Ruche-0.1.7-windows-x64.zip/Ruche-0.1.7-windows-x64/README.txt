Ruche 0.1.7 for Windows

Run Ruche.exe. This folder is portable: your library, stations and settings live in
%LOCALAPPDATA%\ruche, so they survive moving or replacing this folder.

Source code and licence: GPL-3.0-or-later (LICENSE.txt). libmpv is GPL; Qt and TagLib are LGPL.
